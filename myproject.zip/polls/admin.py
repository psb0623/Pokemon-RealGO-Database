from django.contrib import admin
from django.db.models.query_utils import Q

from .models import Member, Question
# Register your models here.

admin.site.register(Member)
admin.site.register(Question)
