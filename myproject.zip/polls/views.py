from django.shortcuts import render
from django.http import HttpResponse, response
from .models import Member
import time
# Create your views here.

def index(request):
    print(request.GET.get('hello'))
    a = request.GET.get('a')
    b = request.GET.get('b')
    return HttpResponse(int(a) + int(b))

def register(request):
    id = request.GET.get('id')
    pw = request.GET.get('pw')

    if( Member.objects.filter(nickname=id).count() > 0 ):
        return HttpResponse("중복된 닉네임입니다")

    m = Member(nickname=id, password=pw)
    m.save()

    return HttpResponse("등록에 성공하였습니다.")

def login(request):
    time.sleep(3)
    id = request.GET.get('id')
    pw = request.GET.get('pw')

    if( Member.objects.filter(nickname=id, password=pw).count() == 0 ):
        return HttpResponse("로그인에 실패하였습니다.")


    return HttpResponse("로그인에 성공하였습니다.")