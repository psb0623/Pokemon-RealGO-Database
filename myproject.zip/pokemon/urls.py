from django.urls import path, include
from .views import BoxViewSet
from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register('box', BoxViewSet)


urlpatterns = [
    #path('', views.index, name='index'),
    # path('box', views.box, name='box'),
    path('add', views.add, name='add'),
    path('delete', views.delete, name='delete'),
    path('api/box/', views.BoxListAPI.as_view()),
    path('api/box/<int:user_id>', views.BoxListAPI.as_view()),
    path('gacha/', views.GachaAPI.as_view()),
    path('', include(router.urls)),
]