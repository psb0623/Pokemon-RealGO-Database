from django.db.models.query import QuerySet
from django.shortcuts import get_object_or_404, render
from django.http import HttpResponse
from django.contrib import auth
import random
import rest_framework

from .models import *
from django.core import serializers

from rest_framework.response import Response
from rest_framework.views import APIView
from .serializers import *

from rest_framework import viewsets
from rest_framework.authentication import SessionAuthentication, BasicAuthentication 
# Create your views here.

class BoxListAPI(APIView):
    def get(self, request):
        print(request.user)
        print(request.auth)
        queryset = Box.objects.filter(user = request.user.id)
        serializer = BoxSerializer(queryset, many=True)
        return Response(serializer.data)

    def put(self, request, **kwargs):
        if kwargs.get('user_id') is None:
            return Response("invalid request")
        else:
            user_id = kwargs.get('user_id')
            box = Box.objects.get(user=request.user.id, id=user_id)
            box.selected = request.data['select']
            box.save()
            return Response("test ok")
    
    def delete(self, request, **kwargs):
        if kwargs.get('user_id') is None:
            return Response("invalid request")
        else:
            user_id = kwargs.get('user_id')
            box = Box.objects.get(user=request.user.id, id=user_id)
            box.delete()
            return Response("test ok")


prob = [
    [2.5,2.5,2.5,2.5,10,10,10,30,0,10,10,0,10],
    [5,5,5,5,10,10,10,10,0.5,10,10,0.5,10],
    [7,7,7,7,10,10,10,0,5,10,10,5,10]
]

skillprob = [1, 29, 50 ,20]

class GachaAPI(APIView):
    def post(self, request):
        # Box.objects.last.id
        print(request.data['gacha'])
        gacha = int( request.data['gacha'] )
        pid = random.choices(range(1, 14), weights=prob[gacha])
        pokemon = Pokemon.objects.get(id = pid[0])

        queryset = Learnable.objects.filter(pokemon = pokemon.id)

        mx = queryset.count()-1


        idx = random.sample(range(0, max(mx+2, 4)), 4)

        for i in range(0, 4):
            idx[i] = min( idx[i], mx)

        idx.sort()

        skill1 = queryset[idx[0]].skill
        skill2 = queryset[idx[1]].skill
        skill3 = queryset[idx[2]].skill
        skill4 = queryset[idx[3]].skill

        box = Box(
            user = request.user,
            pokemon = pokemon,
            skill1 = skill1,
            skill2 = skill2,
            skill3 = skill3,
            skill4 = skill4
        )
        box.save()
        serializer = BoxSerializer(box)
        return Response(serializer.data)

class BoxViewSet(viewsets.ModelViewSet):
    queryset = Box.objects.all()
    serializer_class = BoxSerializer

    def perform_create(self, serializer):
        serializer.save(user = auth.get_user(self.request))


def index(request):
    return HttpResponse("Hello, world.")

def box(request):
    id = request.GET.get('name')
    # return HttpResponse(  Box.objects.filter(player = id).select_related('pokemon') ) 
    rs = Box.objects.filter(player = id)
    serializer = BoxSerializer(rs, many=True)
    return Response(serializer.data)


def add(request):
    id = request.GET.get('name')

    box = Box(
        player = Player.objects.get(id = id),
        pokemon = Pokemon.objects.get(id = 4),
        skill1 = Skill.objects.get(id = 1),
        skill2 = Skill.objects.get(id = 2),
        skill3 = Skill.objects.get(id = 3),
        skill4 = Skill.objects.get(id = 4)
    )

    box.save()

    return HttpResponse("포켓몬을 잡았다!!")


def delete(request):
    user = request.GET.get('name')
    boxid = request.GET.get('boxid')

    box = get_object_or_404(Box, id=boxid)
    box.delete()

    return HttpResponse("포켓몬을 놓아줬다!!")

