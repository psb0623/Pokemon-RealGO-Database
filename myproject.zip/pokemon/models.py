from typing_extensions import NotRequired
from django.db import models
from django.db.models.fields.related import ForeignKey
from account.models import User
import json

# Create your models here.
class Type(models.Model):
    name = models.CharField(max_length=10)

    def __str__(self):
        return self.name

class Category(models.Model):
    name = models.CharField(max_length=10)

    def __str__(self):
        return self.name

class Pokemon(models.Model):
    name = models.CharField(max_length=12)
    type1 = models.ForeignKey(Type, on_delete=models.CASCADE, related_name='t1')
    type2 = models.ForeignKey(Type, on_delete=models.CASCADE, related_name='t2')
    hp = models.IntegerField(default=0)
    atk = models.IntegerField(default=0)
    dfs = models.IntegerField(default=0)
    stk = models.IntegerField(default=0)
    sef = models.IntegerField(default=0)
    spd = models.IntegerField(default=0)

    def __str__(self):
        return self.name

    def toJSON(self):
        self.name

class Skill(models.Model):
    name = models.CharField(max_length=12, blank=True)
    type = models.ForeignKey(Type, on_delete=models.CASCADE)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    dmg = models.IntegerField(default=0)
    acc = models.IntegerField(default=0)
    # pp = models.IntegerField(default=0)

    def __str__(self):
        return self.name

class Player(models.Model):
    name = models.CharField(max_length=12)
    auth = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Learnable(models.Model):
    pokemon = models.ForeignKey(Pokemon, on_delete=models.CASCADE)
    skill = models.ForeignKey(Skill, on_delete=models.CASCADE)
    def __str__(self):
        return str(self.pokemon) + '-' + str(self.skill)

class Box(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    pokemon = models.ForeignKey(Pokemon, on_delete=models.CASCADE)
    skill1 = models.ForeignKey(Skill, on_delete=models.CASCADE, related_name='s1')
    skill2 = models.ForeignKey(Skill, on_delete=models.CASCADE, related_name='s2')
    skill3 = models.ForeignKey(Skill, on_delete=models.CASCADE, related_name='s3')
    skill4 = models.ForeignKey(Skill, on_delete=models.CASCADE, related_name='s4')
    selected = models.IntegerField(default=0)
    def __str__(self):
        return str(self.user) + '의 ' + str(self.pokemon)
       
 


 