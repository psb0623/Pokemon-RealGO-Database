from rest_framework import serializers
from .models import *

class TypeSerializer(serializers.ModelSerializer):
    class Meta :
        model = Type
        fields = '__all__'
    

class CategorySerializer(serializers.ModelSerializer):
    class Meta :
        model = Category
        fields = '__all__'

class PokemonSerializer(serializers.ModelSerializer):
    class Meta :
        model = Pokemon
        fields = '__all__'

    def to_representation(self, instance):
        response = super().to_representation(instance)
        response['type1'] = TypeSerializer(instance.type1).data
        response['type2'] = TypeSerializer(instance.type2).data
        return response

class SkillSerializer(serializers.ModelSerializer):
    class Meta :
        model = Skill
        fields = '__all__'

    def to_representation(self, instance):
        response = super().to_representation(instance)
        response['type'] = TypeSerializer(instance.type).data
        response['category'] = CategorySerializer(instance.category).data
        return response

class PlayerSerializer(serializers.ModelSerializer):
    class Meta :
        model = Player
        fields = '__all__'

class BoxSerializer(serializers.ModelSerializer):
    user = serializers.ReadOnlyField(source = 'user.nickname')
    class Meta :
        model = Box
        fields = '__all__'

    def to_representation(self, instance):
        response = super().to_representation(instance)
        # response['player'] = PlayerSerializer(instance.player).data
        response['pokemon'] = PokemonSerializer(instance.pokemon).data
        response['skill1'] = SkillSerializer(instance.skill1).data
        response['skill2'] = SkillSerializer(instance.skill2).data
        response['skill3'] = SkillSerializer(instance.skill3).data
        response['skill4'] = SkillSerializer(instance.skill4).data
        return response
       
 


 