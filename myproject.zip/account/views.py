from django.http.response import HttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.authtoken.models import Token

from django.contrib.auth import authenticate
from .models import User
from .serializers import UserSerializer
from . import models
from pokemon.models import Box

class SignupView(APIView):
    def post(self, request):
        try:
            user = User.objects.create_user(email=request.data['email'], nickname=request.data['id'], name=request.data['name'], password=request.data['password'])
            user.save()
            token = Token.objects.create(user=user)
            return Response({"Success":1, "Message":token.key})

        except Exception as e:
            return Response({"Success":0, "Message":str(e)})

class LoginView(APIView):
    def post(self, request):
        print(request.data['id'])
        user = authenticate(username=request.data['id'], password=request.data['password'])
        if user is not None:
            token = Token.objects.get(user=user)
            return Response({"Token": token.key})
        else:
            return Response(status=401)

class ProfileView(APIView):
    def get(self, request):
        user = request.user
        serializer = UserSerializer(user)
        return Response(serializer.data)

    def put(self, request):
        user = request.user
        price = int(request.data['price'])
        if(user.money < price):
            return Response({"message":"fail"})
        else:
            user.money -= price
            user.save()
            return Response({"message":"success"})
        